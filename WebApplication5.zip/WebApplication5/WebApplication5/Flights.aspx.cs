﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class Flights : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Label5.Text = Session["name"].ToString();
            HttpCookie req = Request.Cookies["UserInfo"];
            if(req != null)
            {
                Label6.Text = req["Pass"].ToString();
            }
        }

        protected void LinkButton2_Command(object sender, CommandEventArgs e)
        {
            if (e.CommandName == "Book")
            {
                string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
                string FlightId = commandArgs[0];
                string FromCity = commandArgs[1];
                string ToCity = commandArgs[2];
                string Price = commandArgs[3];

                Response.Redirect("Booking.aspx?FlightId=" + FlightId + "&FromCity=" + FromCity + "&ToCity=" + ToCity + "&Price=" +Price);
            }
        }


    }
}
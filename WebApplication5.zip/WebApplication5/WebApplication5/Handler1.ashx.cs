﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication5
{
    /// <summary>
    /// Summary description for Handler1
    /// </summary>
    public class Handler1 : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            String imageid = context.Request.QueryString["ImID"];
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ebookConnectionString"].ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("Select ProfileImage from Student where ID= " + imageid, con))
                    {
                        con.Open();
                        SqlDataReader dr = command.ExecuteReader();
                        dr.Read();
                        context.Response.BinaryWrite((Byte[])dr[0]);
                        con.Close();
                        context.Response.End();
                    }
                }
            }
            catch
            {
            }
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }
}
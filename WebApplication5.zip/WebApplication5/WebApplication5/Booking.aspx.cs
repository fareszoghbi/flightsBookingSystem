﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class Booking : System.Web.UI.Page
    {
        private string userId;
        private string flightId;
        private string Price;
        protected void Page_Load(object sender, EventArgs e)
        {
            flightId = Request.QueryString["FlightId"];
            string FromCity = Request.QueryString["FromCity"];
            string ToCity = Request.QueryString["ToCity"];
            Price = Request.QueryString["Price"];
            string userName = Session["name"].ToString();
            userId = Session["Id"].ToString();
            username.Text = userName + "  "+ userId;
            
            Label1.Text = userName;
            Label2.Text = FromCity;
            Label3.Text = ToCity;
            Label4.Text = Price;


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Flight.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["eBookingConnectionString"].ToString());
            
            SqlCommand MyCommand = con.CreateCommand();
            try
            {
                con.Open();
                MyCommand.CommandText = "INSERT INTO Booking (ClientID, FlightID, Cost) values (@ClientID, @FlightID, @Cost)";

                MyCommand.Parameters.Add("@ClientID", SqlDbType.Int, 50);
                MyCommand.Parameters.Add("@FlightID", SqlDbType.Int, 50);
                MyCommand.Parameters.Add("@Cost", SqlDbType.Int, 50);

                MyCommand.Parameters["@ClientID"].Value = userId;
                MyCommand.Parameters["@FlightID"].Value = flightId;
                MyCommand.Parameters["@Cost"].Value = Price;

                MyCommand.ExecuteNonQuery();
                Label1.Text = "Success";
            }

            catch (SqlException ex)
            {
                Label1.Text = ex.ToString();
            }
            finally
            {
                con.Close();
            }
        }
    }
}